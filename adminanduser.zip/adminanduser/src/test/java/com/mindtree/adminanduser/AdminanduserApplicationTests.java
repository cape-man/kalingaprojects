package com.mindtree.adminanduser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminanduserApplicationTests {

	@Test
	void contextLoads() {
	}

}
